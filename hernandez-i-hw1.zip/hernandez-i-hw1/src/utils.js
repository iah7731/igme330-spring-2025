export let randomElement = (array) => 
{
    return Math.floor(Math.random() * array.length);
}